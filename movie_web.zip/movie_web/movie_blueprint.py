# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 11:06:12 2019

@author: akshay_gane
"""
import webbrowser

class Movies():
    def __init__(self, movie_title, movie_storyline, movie_poster, movie_trailer):
        self.title = movie_title
        self.storyline = movie_storyline
        self.poster = movie_poster
        self.trailer = movie_trailer
        
    def show_trailer(self):
        webbrowser.open(self.trailer)
        
    def show_poster(self):
        webbrowser.open(self.poster)
    